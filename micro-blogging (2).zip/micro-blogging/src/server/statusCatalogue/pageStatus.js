const pageStatus = {
    ACTIVE: 1,
    DELETED: 99
}

module.exports = {
    pageStatus
}