const tokenStatus = {
BLACKLISTED_TRUE:1,
BLACKLISTED_FALSE:0
}

module.exports={
    tokenStatus
}