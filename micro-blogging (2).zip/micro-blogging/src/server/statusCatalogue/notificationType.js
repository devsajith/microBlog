const notificationType = {
    MESSAGE:1,
    FRIEND_REQUEST:2
}

module.exports={
    notificationType
}