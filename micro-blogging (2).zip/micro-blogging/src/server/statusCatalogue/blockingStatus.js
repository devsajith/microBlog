const status = {
    BLOCKED: 0,
    UN_BLOCKED: 1
}

module.exports = {
    status
}