const userStatus = {
    ACTIVE:1,
    INCOMPLETE_PROFILE:2,
    INACTIVE:0,
    DELETED:99

}

module.exports={
    userStatus
}