const accessStatus = {
    PRIVATE: 0,
    PUBLIC: 1
}

module.exports = {
    accessStatus
}