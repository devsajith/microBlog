const notificationDelivery = {
    READ:1,
    UNREAD:0
}

module.exports={
    notificationDelivery
}