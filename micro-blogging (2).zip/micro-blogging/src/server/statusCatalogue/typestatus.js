const typeStatus = {
    FRIEND_REQUEST:1,
    FRIEND_ACCEPT:2,
    CHAT:0
}

module.exports={
    typeStatus
}