const friendStatus = {

    PENDING: 0,
    FRIEND: 1,
    NOT_FRIEND: 2,
    SELF: 3
}

module.exports = {
    friendStatus
}