const friendRequestStatus = {
    ACCEPT: 1,
    REJECT: 2,
    PENDING: 0
}

module.exports = {
    friendRequestStatus
}