const notificationStatus = {
    UNREAD: 0,
    READ: 1,
    DELETED:2
}

module.exports = {
    notificationStatus
}