const status = {
    DELETED: 99,
    ACTIVE: 1
}


module.exports = status