const weightForPosts = {
    COMMENT_WEIGHT: 5
}

module.exports = {
    weightForPosts
}