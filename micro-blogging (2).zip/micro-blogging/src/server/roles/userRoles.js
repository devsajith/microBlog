const userRoles={
    USER:1,
    ADMIN:2
}

module.exports={
    userRoles
}