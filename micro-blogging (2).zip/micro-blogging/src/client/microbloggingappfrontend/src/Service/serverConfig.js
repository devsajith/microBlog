const config={
    // API_URL:"http://micro-blog-dev-api.innovaturelabs.intra",
    // API_URL:"https://a5cd-122-186-163-158.ap.ngrok.io",
    API_URL:"http://localhost:9001"
    
}

export default config;